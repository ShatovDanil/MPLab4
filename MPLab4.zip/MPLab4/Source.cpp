#include <iostream>
using namespace std;
extern "C" float sumr(int bottom, int top);
int main()
{
	int bottom = 1, top = 2;
	cout << "bottom" << endl;	cin >> bottom;
	cout << "top" << endl; cin >> top;
	double y = sumr(bottom, top);
	cout << "y = " << y << endl;

	return 0;
}
