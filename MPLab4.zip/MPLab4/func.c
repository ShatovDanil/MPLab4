#include "math.h"
extern  float fun_el(int x)
{
	float f = 0;
	f = (1 / tan(x)) + sin(x);
	if (f < 0) f = -f;
	return f;
}
