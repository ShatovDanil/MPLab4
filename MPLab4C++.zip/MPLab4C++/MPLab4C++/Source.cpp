#include <iostream>
#include <cmath>
using namespace std;
float fun_el(int x) {
    float f = 0;
    f = (1 / tan(x)) + sin(x);
    if (f < 0) f = -f;
    return f;
}
float sumr(int bottom, int top) {
    float bottomValue = fun_el(bottom);
    float topValue = fun_el(top);
    float difference = fabs(topValue) - fabs(bottomValue);
    return difference;
}

int main() {
    int bottom = 1, top = 2;

    float Result = sumr(bottom, top);
    cout << "R = " << Result << endl;

    return 0;
}
